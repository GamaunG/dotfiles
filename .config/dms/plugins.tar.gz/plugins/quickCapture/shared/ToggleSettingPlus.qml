import QtQuick
import qs.Common
import qs.DCommon.Widgets

Item {
    id: root

    required property string settingKey
    required property string label
    property string description: ""
    property bool defaultValue: false
    property bool value: defaultValue

    width: parent.width
    height: 36 // Giảm chiều cao

    // Dynamic Opacity for disabled state
    opacity: enabled ? 1 : 0.5
    Behavior on opacity { NumberAnimation { duration: Theme.shortDuration } }

    property bool isInitialized: false
    readonly property bool isDirty: value !== defaultValue

    function resetToDefault() {
        console.log(`[ToggleSettingPlus] Resetting ${settingKey} to ${defaultValue}`);
        value = defaultValue;
    }

    function loadValue() {
        const settings = findSettings();
        if (settings) {
            const loadedValue = settings.loadValue(settingKey, defaultValue);
            value = loadedValue;
            isInitialized = true;
        }
    }

    Component.onCompleted: {
        Qt.callLater(loadValue);
    }

    onValueChanged: {
        if (!isInitialized)
            return;
        const settings = findSettings();
        if (settings) {
            settings.saveValue(settingKey, value);
        }
    }

    function findSettings() {
        let item = parent;
        while (item) {
            if (item.saveValue !== undefined && item.loadValue !== undefined) {
                return item;
            }
            item = item.parent;
        }
        return null;
    }

    HoverHandler {
        id: rootHoverHandler
    }

    Rectangle {
        id: highlightBg
        anchors.fill: parent
        anchors.leftMargin: -12
        anchors.rightMargin: -12
        anchors.topMargin: -6
        anchors.bottomMargin: -6
        radius: Theme.cornerRadius
        color: rootHoverHandler.hovered ? Theme.withAlpha(Theme.primary, 0.08) : "transparent"
        Behavior on color { ColorAnimation { duration: 150 } }
    }

    MouseArea {
        id: clickArea
        anchors.fill: parent
        anchors.leftMargin: -12
        anchors.rightMargin: -12
        anchors.topMargin: -6
        anchors.bottomMargin: -6
        cursorShape: Qt.PointingHandCursor
        onClicked: {
            root.value = !root.value;
        }
    }

    Row {
        id: layoutRow
        anchors.fill: parent
        spacing: Theme.spacingM

        Column {
            width: parent.width - toggle.width - parent.spacing
            spacing: Theme.spacingXS
            anchors.verticalCenter: parent.verticalCenter

            Row {
                spacing: Theme.spacingXS
                width: parent.width

                StyledText {
                    text: root.label
                    font.pixelSize: Theme.fontSizeLarge
                    font.weight: Font.Medium
                    color: Theme.surfaceText
                    elide: Text.ElideRight
                    maximumLineCount: 1
                    width: Math.min(implicitWidth, parent.width - (infoIcon.visible ? infoIcon.width + parent.spacing : 0))
                }

                DIcon {
                    id: infoIcon
                    name: "info"
                    size: 16
                    color: Theme.primary
                    visible: root.description !== ""
                    anchors.verticalCenter: parent.verticalCenter
                    opacity: 0.6

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        onEntered: sharedTooltip.show(root.description, infoIcon)
                        onExited: sharedTooltip.hide()
                    }
                }
            }
        }

        DTooltipV2 {
            id: sharedTooltip
        }

        DToggle {
            id: toggle
            anchors.verticalCenter: parent.verticalCenter
            checked: root.value
            onToggled: isChecked => {
                root.value = isChecked;
            }
        }
    }
}
