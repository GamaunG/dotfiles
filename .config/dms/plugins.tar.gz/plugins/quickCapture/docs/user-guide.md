# User Guide

## Quick Start

| Action | Result |
| --- | --- |
| **Left Click** | Open the widget popout |
| **Middle Click** | Region capture |
| **Right Click** | Paste from clipboard |
| **Drop Image** | Drag an image onto the icon to annotate |
| **<kbd>Print</kbd>** | Capture using the default mode |

1. Trigger a capture from the bar icon, Control Center, or <kbd>Print</kbd>.
2. Drag to select an area.
   Drag one of the four corner handles to resize the current selection.
   Hold <kbd>Ctrl</kbd> and drag with the left mouse button to move the current selection without resizing it.
3. Annotate with the toolbar, shortcuts, or radial menus.
4. Press <kbd>Enter</kbd> to finish or <kbd>Esc</kbd> to discard.

### Scrolling Capture

Select a region, press <kbd>Space</kbd> or <kbd>Enter</kbd> to confirm, scroll the content, then press <kbd>Enter</kbd> to finish stitching. Adjust the scroll interval in settings.

## Annotation Tools

### Tool Selection

| Shortcut | Tool |
| --- | --- |
| <kbd>1</kbd> | Pen |
| <kbd>2</kbd> | Line |
| <kbd>3</kbd> | Arrow |
| <kbd>4</kbd> | Rectangle |
| <kbd>Q</kbd> | Ellipse |
| <kbd>W</kbd> | Text |
| <kbd>E</kbd> | Pixelate |
| <kbd>R</kbd> | Redact |
| <kbd>A</kbd> | Stamp |
| <kbd>S</kbd> | Highlighter |
| <kbd>D</kbd> | Focus Spotlight |
| <kbd>F</kbd> | Color Picker |
| <kbd>T</kbd> | Eraser |
| <kbd>Z</kbd> | Area Zoom (Callout) |
| <kbd>B</kbd> | Background Options |
| <kbd>I</kbd> | Insert Image |
| <kbd>M</kbd> | Toggle Watermark |
| <kbd>O</kbd> | OCR Text Recognition |
| <kbd>G</kbd> (hold) | Magnifier Lens |
| <kbd>V</kbd> | Select |
| <kbd>X</kbd> | Toggle annotations |
| <kbd>Tab</kbd> | Toggle Select and the last active tool |

### Drawing and Editing

- Scroll the mouse wheel to adjust brush or font size.
- Middle-click an element to delete it.
- Select a vector with <kbd>V</kbd>, then press <kbd>C</kbd> to duplicate it.
- Press <kbd>C</kbd> without a selection to paste the last copied vector.
- Use <kbd>Ctrl</kbd> + <kbd>Z</kbd> and <kbd>Ctrl</kbd> + <kbd>Y</kbd> for undo and redo.
- Drag with Text to create a speech bubble; a single click creates normal text.
- Drag with Stamp to create a leader line; a single click creates a normal stamp.

Hold <kbd>Shift</kbd> while drawing to constrain shapes: Pen draws straight lines; Line, Arrow, and Highlighter snap to 15-degree increments; Ellipse makes a circle; Rectangle, Redact, and Pixelate make a square.

### Crop Controls

- Hold <kbd>Shift</kbd> while creating a crop to constrain it to a 1:1 square. The same modifier works when resizing from a corner handle.
- Hold <kbd>Ctrl</kbd> and drag to move the current crop without changing its size. The drag can start anywhere on the canvas; corner and edge handles still resize the crop.

### Popover Toolbars and Radial Menus

| Interaction | Result |
| --- | --- |
| Right-click on canvas | Open eight customizable tool presets |
| <kbd>Shift</kbd> + right-click with Stamp active | Stamp options |
| <kbd>Shift</kbd> + right-click with Text active | Text options |
| <kbd>Shift</kbd> + right-click with Line active | Line options |

### Canvas Zoom and Pan

- **Focal Zoom**: Hold <kbd>Ctrl</kbd> + <kbd>Shift</kbd> and scroll the mouse wheel to zoom in or out centered at the cursor location.
- **Keyboard Zoom**: Press <kbd>+</kbd> or <kbd>=</kbd> to zoom in, <kbd>-</kbd> to zoom out, and <kbd>0</kbd> to reset zoom to 100%.
- **Stroke Size**: Press <kbd>[</kbd> to decrease stroke size and <kbd>]</kbd> to increase stroke size.
- **Free Pan**: Hold <kbd>Ctrl</kbd> + <kbd>Shift</kbd> and drag with the left mouse button to pan freely across the canvas.
- **Directional Scroll**: Hold <kbd>Ctrl</kbd> and scroll to pan vertically; hold <kbd>Shift</kbd> and scroll to pan horizontally.

### Special Tools

- Hold <kbd>G</kbd> for the magnifier lens and scroll to adjust zoom from 1.5x to 4x.
- Press <kbd>Z</kbd> to draw a callout and scroll to adjust zoom from 100% to 500%.

## Keyboard Shortcuts

| Key | Action |
| --- | --- |
| <kbd>Enter</kbd> | Done; save or copy according to settings (or commit text when typing) |
| <kbd>Shift</kbd> + <kbd>Enter</kbd> / <kbd>Ctrl</kbd> + <kbd>Enter</kbd> | Insert newline when typing text |
| <kbd>Esc</kbd> | Discard and close (or cancel text input when typing) |
| <kbd>Ctrl</kbd> + <kbd>Z</kbd> | Undo |
| <kbd>Ctrl</kbd> + <kbd>Y</kbd> / <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>Z</kbd> | Redo |
| <kbd>Ctrl</kbd> + <kbd>S</kbd> | Save to file |
| <kbd>Ctrl</kbd> + <kbd>C</kbd> | Copy to clipboard |
| <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>C</kbd> | Anonymous copy |
| <kbd>Ctrl</kbd> + <kbd>V</kbd> | Paste image or text from system clipboard |
| <kbd>Ctrl</kbd> + <kbd>A</kbd> | Copy and save |
| <kbd>Ctrl</kbd> + <kbd>F</kbd> | Float image |
| <kbd>Ctrl</kbd> + <kbd>X</kbd> | Crop or resize |
| <kbd>+</kbd> / <kbd>=</kbd> | Zoom in canvas |
| <kbd>-</kbd> | Zoom out canvas |
| <kbd>0</kbd> | Reset canvas zoom to 100% |
| <kbd>[</kbd> | Decrease stroke size |
| <kbd>]</kbd> | Increase stroke size |
| <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + Drag | Free pan canvas |
| <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + Scroll | Focal zoom canvas centered at cursor |
| <kbd>Ctrl</kbd> + <kbd>1</kbd> to <kbd>4</kbd> | Select color slots 1 to 4 |
| <kbd>Ctrl</kbd> + <kbd>Q</kbd> to <kbd>R</kbd> | Select color slots 5 to 8 |

## Screen Recording

Quick Capture supports screen recording via GPU hardware acceleration or CPU fallback.

### Recording Backends
- **Auto (Default)**: Automatically detects available recorders. Prefers native `gpu-screen-recorder`, then Flatpak `gpu-screen-recorder`, and falls back to CPU `wf-recorder` if no GPU recorder is found.
- **GPU Screen Recorder (NVENC / VA-API)**: Hardware-accelerated recording with pause/resume support and multi-track audio capture. Works with native system packages or Flatpak (`com.dec05eba.gpu_screen_recorder`).
- **GPU Screen Recorder (Flatpak)**: Explicitly forces the use of Flathub Flatpak package. System-wide installation is recommended for proper KMS/DRI screen capture permissions:
  ```bash
  flatpak install --system com.dec05eba.gpu_screen_recorder
  ```
- **wf-recorder**: Lightweight CPU libx264 backend (fallback; pause/resume and internal audio mixing are not supported).

## Pin to Desktop

- Press <kbd>Ctrl</kbd> + <kbd>F</kbd> to export and float the image.
- Left-click the floating image to continue editing.
- Right-click it to minimize it; hover the icon to restore it.
- Middle-click the floating image to close it.

## IPC Commands

Commands that capture or open images accept `edit` or `float` as the action:

```bash
dms ipc call quickCapture <command> [arg] edit|float
dms ipc call quickCapture screenshot region edit
dms ipc call quickCapture screenshot region float
```

| Command | Arguments | Description |
| --- | --- | --- |
| `screenshot` | `region`, `full`, `all`, `output`, `window`, `last`, or `scroll`; action | Trigger capture |
| `selectFile` | action | Open the file browser |
| `fromClipboard` | action | Annotate an image from the clipboard |
| `openImage` | path, action | Open an image in the annotator |
| `close` | none | Close the annotator |
| `showHistory` | none | Open recent edits |

See the [IPC and Settings Reference](ipc-and-settings.md) for the complete command and configuration reference.

![Keybinding example](../setup_example.png)
