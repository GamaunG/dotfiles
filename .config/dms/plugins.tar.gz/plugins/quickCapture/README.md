# DMS Quick Capture

<p align="center">
  <a href="https://github.com/AvengeMedia/dms-plugin-registry/issues/432">
    <img src="https://img.shields.io/badge/Upvote%20on%20DMS%20Plugin%20Registry-%E2%86%91-blue?style=flat-square" alt="Upvote on DMS Plugin Registry"/>
  </a>
</p>

Screenshot annotation and screen recording plugin for DankMaterialShell.

<img src="screenshot.png" width="800" alt="Screenshot">

## Documentation

- **[User Guide](docs/user-guide.md)**: capture workflow, annotation tools, shortcuts, floating images, and IPC commands.
- **[Documentation Index](docs/index.md)**: architecture, annotation engine, settings reference, and contributor documentation.

## Requirements

| Dependency                           | Purpose                                            |
| ------------------------------------ | -------------------------------------------------- |
| DankMaterialShell >= **1.6.0**       | Required for floating window and scrolling capture |
| **gpu-screen-recorder**              | Screen recording backend (Hardware NVENC / VA-API; native or Flatpak `com.dec05eba.gpu_screen_recorder`) |
| **wf-recorder**                      | Alternative CPU screen recording backend (Software libx264, fallback when GPU encoder is unavailable) |
| **ffmpeg**                           | Video thumbnail generation                         |
| **ImageMagick** (`magick`/`mogrify`) | WebP/JPEG exports and OCR/QR crop                  |
| **img2pdf**                          | PDF export                                         |
| **tesseract**                        | OCR text scanner                                   |
| **zbar** (`zbarimg`)                 | QR scanner                                         |
| **pkill** (`procps` / `procps-ng`)   | Signaling Flatpak GPU Screen Recorder sessions      |

> [!NOTE]
> At least one recording backend (`gpu-screen-recorder` or `wf-recorder`) is required for video capture. `gpu-screen-recorder` is recommended for optimal performance, pause/resume support, and audio (supports both native package and Flatpak `com.dec05eba.gpu_screen_recorder`); `wf-recorder` serves as a lightweight CPU-based alternative (video only, pause/resume not supported).
>
> If using Flatpak GPU Screen Recorder, system installation is recommended for proper KMS/DRI screen capture permissions (`pkill` on host is used to control pause/stop/cancel):
> ```bash
> flatpak install --system com.dec05eba.gpu_screen_recorder
> ```

## Install

Via DMS CLI:

```bash
dms plugins install quickCapture
```

Or manually:

```bash
git clone https://github.com/hthienloc/dms-quick-capture ~/.config/DankMaterialShell/plugins/quickCapture
```

## Translations

Quick Capture supports native DMS 1.6+ sideload translations located in `translations/<locale>.json`.

Translations are crowdsourced and managed online via **POEditor**:  
👉 **[Contribute translations on POEditor (Project #839330)](https://poeditor.com/projects/view?id=839330)**

<!-- TRANSLATIONS_TABLE_START -->
| Language | Locale | Progress | Coverage | Status | Contributors |
| :--- | :--- | :---: | :---: | :---: | :--- |
| Arabic | `ar` | 465/491 | 94.7% | 🟡 In Progress | — |
| Bulgarian | `bg` | 68/491 | 13.8% | 🟡 In Progress | — |
| German | `de` | 83/491 | 16.9% | 🟡 In Progress | — |
| Esperanto | `eo` | 63/491 | 12.8% | 🟡 In Progress | — |
| Spanish | `es` | 82/491 | 16.7% | 🟡 In Progress | — |
| Persian | `fa` | 58/491 | 11.8% | 🟡 In Progress | — |
| French | `fr` | 70/491 | 14.3% | 🟡 In Progress | — |
| Hebrew | `he` | 67/491 | 13.6% | 🟡 In Progress | — |
| Hungarian | `hu` | 68/491 | 13.8% | 🟡 In Progress | — |
| Italian | `it` | 465/491 | 94.7% | 🟡 In Progress | — |
| Japanese | `ja` | 80/491 | 16.3% | 🟡 In Progress | — |
| Korean | `ko` | 80/491 | 16.3% | 🟡 In Progress | — |
| Dutch | `nl` | 67/491 | 13.6% | 🟡 In Progress | — |
| Polish | `pl` | 64/491 | 13.0% | 🟡 In Progress | — |
| Portuguese | `pt` | 67/491 | 13.6% | 🟡 In Progress | — |
| Russian | `ru` | 82/491 | 16.7% | 🟡 In Progress | — |
| Swedish | `sv` | 55/491 | 11.2% | 🟡 In Progress | — |
| Turkish | `tr` | 43/491 | 8.8% | 🟡 In Progress | — |
| Ukrainian | `uk` | 68/491 | 13.8% | 🟡 In Progress | — |
| Vietnamese | `vi` | 82/491 | 16.7% | 🟡 In Progress | — |
| Chinese (Simplified) | `zh-CN` | 491/491 | 100.0% | 🟢 Complete | [@Lemon-mon-254](https://github.com/Lemon-mon-254) |
| Chinese (Traditional) | `zh-TW` | 62/491 | 12.6% | 🟡 In Progress | — |
<!-- TRANSLATIONS_TABLE_END -->

### Contributing Translations

1. Extract the latest translatable strings:
    ```bash
    python3 scripts/i18n.py extract
    ```
2. Edit your language file under `translations/<locale>.json` (or add a new language with `python3 scripts/i18n.py add-lang <locale>`).
3. Check translation coverage and update the table:
    ```bash
    python3 scripts/i18n.py status --readme
    ```

## Credits

- **Quick Capture toolbar**
    - Version 1: ![Quick Capture toolbar version 1](assets/quick_capture_toolbar_v1.png)
    - Version 5: ![Quick Capture toolbar version 5](assets/quick_capture_toolbar_v5.png)
- **[Gradia Capture](https://github.com/AlexanderVanhee/gradia-capture)** and **[Noctalia](https://github.com/noctalia-dev/noctalia)** — Inspiration for the toolbar layout and background algorithms
    - ![Gradia Capture toolbar](assets/gradia_capture_toolbar.png)
    - ![Noctalia toolbar](assets/noctalia_toolbar.png)
- **[Flameshot](https://github.com/flameshot-org/flameshot)** — Inspiration for the radial menu and tool interaction patterns
- **[Snapzy](https://github.com/duongductrong/Snapzy)** — Inspiration for the float image / continue-editing workflow
- **vky** and **bodify** (Discord) — Bug reports and feedback that helped polish the plugin

Thanks to everyone who supported, contributed code, gave feedback, and helped the DankMaterialShell community.

## License

MIT
